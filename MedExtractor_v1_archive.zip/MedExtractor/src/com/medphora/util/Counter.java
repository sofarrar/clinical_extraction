package com.medphora.util;

public class Counter {

	private int value = 1;

	public Counter(int i){this.setValue(i);}
	public Counter(){}
	public void inc () {setValue(getValue() + 1);}
	public int get () {return getValue();}
	@Override public String toString(){ return getValue() + "";}
	public void inc(int i) {setValue(getValue() + i);}
	public void dec() {setValue(getValue() - 1);}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
}
