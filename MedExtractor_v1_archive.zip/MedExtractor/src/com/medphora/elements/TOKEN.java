package com.medphora.elements;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
public class TOKEN {
	
	
	private String token;
	private String norm;
	private int beg;
	private int end;
	private String type;
	private int idx;
	private String pos;
	private String id="";
	private String ontology_id="";
	private int polarity;
	private double confidence;
	private String conditional="";
	private int uncertainty;
	private String codetype="";
	private HashSet<String> code=new HashSet<String>();
	private HashSet<String> cui=new HashSet<String>();
	private HashSet<String> tui=new HashSet<String>();
	private String NE;

	public TOKEN(int key, String[] spanAr, String txt, String _type) {
		
	}

	public TOKEN(int key, int _beg, int _end, String txt, String _type) {
		this.beg = _beg;
		this.end = _end;
		this.token = txt;
		this.type = _type;
		this.idx = key;
		System.out.println(this.token);
	}
	/**
	 * @param key
	 * @param _beg
	 * @param _end
	 * @param txt
	 * @param _text
	 * @param _type
	 * @param _pos
	 * @param _id
	 */
	public TOKEN(int key, String _beg, String _end, String txt, String _text, String _type,String _pos,String _id) {
		this.beg = Integer.parseInt(_beg);
		this.end = Integer.parseInt(_end);
		this.norm = txt;
		this.token = _text;
		this.type = _type;//
		//System.out.println("adding " + key +":" + this.beg + " " + this.end + " " + _type + " " + this.type);
		this.idx = key;
		//System.out.println(this.token);
		this.pos = _pos;
		this.id = _id;
	}
	public TOKEN(String oid, String _beg, String _end, String _type, String _id) {
		this.ontology_id = oid;
		this.beg = Integer.parseInt(_beg);
		this.end = Integer.parseInt(_end);
		this.type = _type;
		this.id = _id;
		this.idx = Integer.parseInt(oid);
	}

	public TOKEN(String _codetype, String _code, String _cui, String _tui,String _type, String _id) {
		this.codetype = _codetype; 
		this.code.add(_code);
		this.cui.add(_cui);
		this.tui.add(_tui);
		this.type = _type;
		this.id = _id;
	}

	public int getTokenNum(){return this.idx;}
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		if (this.type.equals("ne")) sb.append(this.ontology_id  + " "+ this.polarity+" ");
		if (this.type.equals("umls")) sb.append(this.ontology_id  + " "+ this.codetype+" " + this.code);

		if (token!=null && token.length()>0){ 
			sb.insert(0,this.token + " " +  this.beg+"-"+ this.end+" ");
		}
		else {sb.insert(0,this.norm + " " +  this.beg+"-"+ this.end+" ");
		}
		return sb.toString();
	}
	public String getToken(){
		if (token.length()>0) return this.token;
		else return this.norm;
	}
	public String getType() {	return this.type;}
	public int getBeg() { return this.beg;}
	public int getEnd() { return this.end;}
	public void updateTxt(String _tok) {this.token =_tok;}
	public HashSet<String> getTUI() {return this.tui;}
	public String printTUI() {return this.tui.toString();}
	public String getPOS() {return this.pos;}
	public String getNE() {		return this.NE;	}
	public String getID() {	return this.id; }
	public String getCodeType() {return this.codetype;}
	public String getCODE() {return this.code.toString();}
	public String getCUI() {return this.cui.toString();}

	public void updateNE(String oid, String pol, String unc, String cond, String conf) {//System.out.println("updating NE + " +oid+" "+ pol+" "+ unc+" "+cond+" "+conf);
		this.ontology_id=oid;
		
		try{this.polarity = Integer.parseInt(pol);}
		catch(NumberFormatException nfep){}
		
		try{this.uncertainty = Integer.parseInt(unc);}
		catch(NumberFormatException nfeu){}
		
		this.conditional = cond;
		
		try{this.confidence = Double.parseDouble(conf);}
		catch(NumberFormatException nfec){}
		
	}

	public void updateFSARRAY(String fsid) {		
		this.ontology_id = fsid; 	
		this.idx = Integer.parseInt(fsid);
	}

	public void mergeNE(TOKEN ne_token) {
		this.beg = ne_token.getBeg();
		this.end = ne_token.getEnd();
		this.polarity = ne_token.polarity;
		this.conditional = ne_token.conditional;
		this.uncertainty = ne_token.uncertainty;
		this.confidence = ne_token.confidence;
		if (ne_token.getToken()!=null){
			this.token = ne_token.getToken();
		}
		//System.out.println("adding " + ne_token.getTUI().size() + " tuis ");
		for (String t : ne_token.getTUI()){ this.tui.add(t); System.out.println(t);}
		//System.out.println("sum TUIS " + this.getTUI().size());
	}
	public void mergeUMLS(TOKEN umls_token) {
		this.cui.add(umls_token.getCUI());
		this.code.add(umls_token.getCODE());
		this.codetype = umls_token.getCodeType();
		//System.out.println("adding " + umls_token.getTUI().size() + " tuis ");
		for (String t : umls_token.getTUI()){ this.tui.add(t); System.out.println(t);}
		//System.out.println("sum TUIS " + this.getTUI().size());
	}
	
	public void addCUI(String match_cui) {
		this.cui.add(match_cui);
		
	}

	public void mergeUMLSNE(TOKEN neumls_token) {

		this.polarity = neumls_token.polarity;
		this.conditional = neumls_token.conditional;
		this.uncertainty = neumls_token.uncertainty;
		this.confidence = neumls_token.confidence;
		this.cui.add(neumls_token.getCUI());
		this.code.add(neumls_token.getCODE());
		this.codetype = neumls_token.getCodeType();
		if (neumls_token.getToken()!=null){
			this.NE = neumls_token.getToken();
		}
		System.out.println("adding " + neumls_token.getTUI().size() + " tuis ");
		for (String t : neumls_token.getTUI()){ this.tui.add(t); System.out.println(t);}
		System.out.println("sum TUIS " + this.getTUI().size());
	
		
	}

	
}
