import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import com.medphora.ctakes.ParseCTAKES;
import com.medphora.elements.TOKEN;
import com.medphora.metamap.process_MM;
import com.medphora.util.IOUtil;
public class MedExtractor {

	public static String CTAKES = "D:\\\\apache-ctakes-3.0.0-incubating\\\\";
	public static String MM = "D:\\MetaMap\\public_mm\\";
	public static TreeMap<Integer,TOKEN> tokenmap = new  TreeMap<Integer,TOKEN> ();
	
	
	public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {
		if (args.length<3) displayArgMessage();
		String note = args[0];//"D:\\medphora_data\\sample_clinicalnote_1.txt";
		String output = args[1];//"D:\\medphora_data_out\\";
		CTAKES=args[2]+IOUtil.fileSeparator+IOUtil.fileSeparator;
		MM=args[3];
		//Start server for metamap
	//	Runtime.getRuntime().exec("cmd /c start " + MM +IOUtil.fileSeparator + "bin"+IOUtil.fileSeparator + "skrmedpostctl_start.bat");

		if (new File(note).isDirectory()){
			ProcessNotes(note,output);
		}
		else {
			ProcessSingleNote(note,output);
		}
		//stop server for metamap
		//Runtime.getRuntime().exec("cmd /c start " + MM +IOUtil.fileSeparator + "bin"+IOUtil.fileSeparator + "skrmedpostctl_stop.bat");
		
	}

	private static void displayArgMessage() {
		System.out.println("Valid argmuments are:\n"+
				"[0] : Clinical note location directory or file\n"+
				"[1] : ouput directory for parse files\n"+
				"[2] : location of root ctakes directory\n"+
				"[3] : location of root metamap directory");
		
	}

	private static void ProcessNotes(String note_dir, String output) 
					throws IOException, SAXException, ParserConfigurationException {
		String[] note_list = IOUtil.getDir(new File(note_dir));
		for (String note : note_list){
			ProcessSingleNote(note,output);
		}
	}

	private static void ProcessSingleNote(String note, String output) 
					throws IOException, SAXException, ParserConfigurationException {
		StringBuffer text = IOUtil.getTextFile(note);
		//ctakes
		ParseCTAKES.main(tokenmap,note,CTAKES);

		//metamap
		
		process_MM.MetaMap(note, output, "mmq", true, MM,tokenmap);

		HashMap<Integer, String> modifiers = collectModifiers();

	}
	private static HashMap<Integer, String> collectModifiers() {
		HashMap<Integer, String> set = new HashMap<Integer,String> ();
		HashSet<String> all_pos = new HashSet<String>();
		for (Integer i : tokenmap.keySet()){
			String _pos = tokenmap.get(i).getPOS();all_pos.add(_pos);
			String tok = tokenmap.get(i).getToken();
			//System.out.println(tokenmap.get(i).getTUI().size() + " tuis ");
			if (modMatch(_pos)) {
				String tui = (tokenmap.get(i).getTUI().size()>0)?tokenmap.get(i).printTUI():"";
				set.put(i,tok);
				System.out.println(i + " " +tok + " (" + tokenmap.get(i).getNE() + ")" +_pos+" TUI:"+
						tui); 
				
			}
		}
		System.out.println(all_pos);
		return set;
	}
	/**
	 * Match modifier pos tag
	 * @param _pos
	 * @return boolean
	 */
	private static boolean modMatch(String _pos) {
		if (_pos.equals("JJ")) return true;//adjective
		if (_pos.equals("RB")) return true;//adverb
		if (_pos.equals("RBR")) return true;//comparative adverb
		if (_pos.equals("JJR")) return true;//comparative adjective
		return false;
	}


}
