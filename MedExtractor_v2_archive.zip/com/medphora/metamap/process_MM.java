package com.medphora.metamap;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

import com.medphora.elements.TOKEN;
import com.medphora.util.IOUtil;


public class process_MM {

	private static int count = 0;
	private static String cui_match;
	private static HashSet<String> cui_matches = null;
	private static long file_size;
	public static boolean debug = false;
	public static HashMap<String,ArrayList<MM>> mm_elements = new HashMap<String,ArrayList<MM>>();

	@Deprecated
	public static void main(String input, String output_dir, String filter,boolean _debug, String MM) throws IOException {
		
		// TODO Auto-generated method stub
		//String input = args[0];
	//	String output_dir = args[1];
		//String filter = args[2];
		//String term = args[3];//term looking for, needs to be in utterance
		//String gold_cui = args[4];
		//int offset_beg = Integer.parseInt(beg);
		debug = _debug;
		
		file_size=new File(input).length();
		
		if (new File(input).isDirectory()){
		String[] inFiles = IOUtil.getDir(new File(input));
		if (debug) System.out.println(inFiles.length+ " files for mm");
		//mm_elements = readFiles(inFiles, filter, input);
		}
		else {//read single file
			
			System.out.println("processing " + input);
			mm_elements = readFile(filter, input);

		}
		
		if (debug) System.out.println("mm_element count = " + mm_elements.size()+ " file");
		
		//wsdMMTerm(output_dir, term, gold_cui, offset_beg, mm_elements);
		
	}
	/**
	 * Run MetaMap on note, return MM IE output as TreeMap, merged with input treemap (from ctakes)
	 * @param input
	 * @param output_dir
	 * @param filter
	 * @param _debug
	 * @param MM
	 * @param cUMLS
	 * @throws IOException
	 */
	public static void MetaMap(String input, String output_dir, String filter,boolean _debug, String MM,TreeMap<Integer,TOKEN> cUMLS) throws IOException {
			String out_fn = input.replace(IOUtil.stripDir(input),output_dir)+".mmq";
			
			System.out.println("processing " + input  + " to " + out_fn);
		//run metamap
//uncomment for production
			//	Runtime.getRuntime().exec("cmd /c start " + MM +IOUtil.fileSeparator + "bin"+IOUtil.fileSeparator + "metamap11v2.bat -q " + input + " " + out_fn);
			mm_elements = readFile(filter, out_fn);
			if (debug)	{System.out.println(mm_elements.keySet());}
			ieMMTerm(cUMLS);
		
	}
	/**
	 *Parse MM output and Simple Merge cTAKES IE results with MetaMap (add all candidate tuis to cUMLS map)
	 * @param cUMLS
	 */
	public static void ieMMTerm(TreeMap<Integer,TOKEN> cUMLS){
		//Matching ctakes output
		for (Integer c : cUMLS.keySet()){
			if (debug)	System.out.println(c + " ctakes index");
			int beg = cUMLS.get(c).getBeg();
			int end = cUMLS.get(c).getEnd();
			String tok = cUMLS.get(c).getToken();
			String ne = cUMLS.get(c).getNE();
			//if (cUMLS.get(c).getToken().contains("stridor")) System.out.println("checking " + cUMLS.get(c).getToken());
			for (String filename : mm_elements.keySet()){
				if (debug) System.out.println("checking " + mm_elements.get(filename).size() + " metamap entities");
				for (int i = 0; i< mm_elements.get(filename).size();i++){
					//if (debug) System.out.println("checking " + i ); 
					String utterance = mm_elements.get(filename).get(i).getUtterance();
			
					if (utterance.length()>0){
				//		if ( mm_elements.get(filename).get(i).toString().length() > 6){ System.out.println(utterance+" " + mm_elements.get(filename).get(i).toString());}
						String cand = "",map="map";//alternating between candidates and maps, candidates are less confident matches 
						//candidate matches
						String match_cui = matchTokMM(filename, tok,ne,i,cand);
						addMatchCui(cUMLS, c, match_cui);
						//map matches
						match_cui = matchTokMM(filename, tok,ne,i,map);
						addMatchCui(cUMLS, c, match_cui);
					}
				}
			}
			
		}
		
	}
	private static void addMatchCui(TreeMap<Integer, TOKEN> cUMLS, Integer c,
			String match_cui) {
		if (match_cui!=null){
			int pre= cUMLS.get(c).getCUI().length();
			cUMLS.get(c).addCUI(match_cui);
			if (debug) System.out.println(" added cui " + match_cui);
			int post= cUMLS.get(c).getCUI().length();
			if (debug && post-pre>0) System.out.println("After mm add" + (post-pre) + " unique cuis");
		}
	}
	private static String matchTokMM(String filename,String term, String ne, int i, String candmap) {
		if (mm_elements.get(filename).get(i).getCandidates("")!=null){
			for (String cm : mm_elements.get(filename).get(i).getCandidates(candmap).keySet()){
				String cui = mm_elements.get(filename).get(i).getCandidates(candmap).get(cm).cuiValue();
				int score = mm_elements.get(filename).get(i).getCandidates(candmap).get(cm).scoreValue();
				String tok = mm_elements.get(filename).get(i).getCandidates(candmap).get(cm).getTerm().toLowerCase();
			//	if (term.contains("stridor"))System.out.println("match " + term + "==" + tok + ":" + score);
				if (tokenMatch(tok,term,ne)){ 
					if (debug) System.out.println("match " + term + "==" + tok + ":" + score);
					return cui; 
				}
			}
		}
		return null;
	}
	/**
	 * match whole word tokens
	 * @param tok
	 * @param term
	 * @return
	 */
	private static boolean tokenMatch(String _tok, String _term, String _ne) {
		String tok = _tok.toLowerCase();
		String term = _term.toLowerCase();
		
		if (tok.equals(term)) return true;
		else if (tok.endsWith(" "+tok)) return true;
		else if (tok.startsWith(tok + " ")) return true;
		else if (tok.contains(" " + tok + " ")) return true;
	if (_ne!=null){
		String ne = _ne.toLowerCase();
		if (ne.endsWith(" "+tok)) return true;
	
		else if (ne.startsWith(tok + " ")) return true;
		else if (ne.contains(" " + tok + " ")) return true;
		//else System.out.println (" no match " + term + " != " + tok);
	}
		return false;
	}
	private static void getCandidateCUI(String filename,HashSet<String> cuis_map, HashSet<String> cuis_cand, int i) {
		if (mm_elements.get(filename).get(i).getCandidates("")!=null){
			for (String cm : mm_elements.get(filename).get(i).getCandidates("").keySet()){
				String cui = mm_elements.get(filename).get(i).getCandidates("").get(cm).cuiValue();
				if (debug)	System.out.println(mm_elements.get(filename).get(i).getCandidates("").get(cm));
				//	return the final map value of the same cui, it will be null if candidate didn't make final mapping
				if (debug)	System.out.println(mm_elements.get(filename).get(i).getCandidates("map").get(cui));
				//cuis_cand.add(cui);
				int score =mm_elements.get(filename).get(i).getCandidates("").get(cm).scoreValue(); 
				if (score==1000){
					System.out.println(mm_elements.get(filename).get(i).getCandidates("").get(cm).cuiValue() + " "+ mm_elements.get(filename).get(i).getCandidates("").get(cm).scoreValue());
					cuis_map.add(cui);
				}
				else if(score >700){
					
					cuis_cand.add(cui);
					
				}
				
			}
		}
	}
	public static HashMap<String,ArrayList<MM>> getMMElements(){return mm_elements;};
	
	public static void wsdMMTerm(String output_dir, String term,
			String gold_cui, int offset_beg,
			HashMap<String, ArrayList<MM>> mm_elements) throws IOException {
		for (String filename : mm_elements.keySet()){
			StringBuffer sb_mm_parse = new StringBuffer();
			HashSet<String> cuis_map = new HashSet<String>();
			HashSet<String> cuis_cand = new HashSet<String>();
			for (int i = 0; i< mm_elements.get(filename).size();i++){
				String utterance = mm_elements.get(filename).get(i).getUtterance();
				if (utterance.length()>0){
					System.out.println(utterance);
					//print out each candidates or each mappings
				//	if (debug || checkTerm(utterance,term)){
						if (debug)		System.out.println("index = " + i + "(" + utterance+")");
						getCandidateCUI(filename, cuis_map,cuis_cand, i);
						
						getMapCUI(filename, cuis_map, cuis_cand, i);
				//	}
				}
				try{
					if (checkTerm(utterance,term)){//sentence contains term to be evaluated
						if (debug)				System.out.println(utterance);
						getAllMatches(term,offset_beg,mm_elements.get(filename).get(i).getCandidates("map"),mm_elements.get(filename).get(i).getCandidates(""));
						if ((mm_elements.get(filename).get(i).getCandidates("map")!=null)&&mm_elements.get(filename).get(i).getCandidates("map").containsKey(gold_cui)){
							String sav_mtc = getMapValue(mm_elements.get(filename).get(i).getCandidates("map"),term,utterance,mm_elements.get(filename).get(i).getOffset());
							cui_match = sav_mtc;
							if (sav_mtc.equals("")||!(sav_mtc.equalsIgnoreCase(term))){//matched the cui, but the term was from another word
								if (debug)			System.out.println("actual term not matched, just cui");
								count = 0;
								cui_match = sav_mtc;
							}
							else if (cui_match.equals(sav_mtc)){
								if (debug)			System.out.println("map match " + gold_cui + " score=" + mm_elements.get(filename).get(i).getCandidates("map").get(gold_cui).scoreValue());
								count = 2;
							}
							else {
								count = 1;						
							}
						}	
						else if (mm_elements.get(filename).get(i).getCandidates("")!=null && mm_elements.get(filename).get(i).getCandidates("").containsKey(gold_cui)){
							if (debug)			System.out.println("candidate match " + gold_cui + " score=" + mm_elements.get(filename).get(i).getCandidates("").get(gold_cui).cuiValue());
							count = 1;
							cui_match = gold_cui;
						}
						else {
							if (mm_elements.get(filename).get(i).getCandidates("map")!=null){
							count = 0;
							cui_match=getMapValue(mm_elements.get(filename).get(i).getCandidates("map"),term,utterance,mm_elements.get(filename).get(i).getOffset());
							if (debug)		System.out.println("no match = "+ cui_match);}
						}
					}
				}
				catch (NullPointerException npe){
					count = 0;
					cui_match="";
					if (debug)				System.out.println("no utterance("+utterance +   ") to match = "+ cui_match);
				}
			}
			sb_mm_parse.append("MAP CUIS:\t"+cuis_map+"\n"+"CAND CUIS:\t"+cuis_cand+"\n");
			IOUtil.putTextFile(output_dir+IOUtil.fileSeparator+filename.split("_")[0]+"_mm_cuis.txt", sb_mm_parse);
		}
	}
	private static void getMapCUI(String filename, HashSet<String> cuis_map,
			HashSet<String> cuis_cand, int i) {
		if (mm_elements.get(filename).get(i).getCandidates("map")!=null){
			for (String cm : mm_elements.get(filename).get(i).getCandidates("map").keySet()){
				if (debug&&mm_elements.get(filename).get(i).getCandidates("map").containsKey(cm))	
				{
					System.out.println(mm_elements.get(filename).get(i).getCandidates("map").get(cm));
					cuis_map.add(mm_elements.get(filename).get(i).getCandidates("map").get(cm).cuiValue());
					System.out.println(mm_elements.get(filename).get(i).getCandidates("map").get(cm).cuiValue() + " "+ mm_elements.get(filename).get(i).getCandidates("map").get(cm).scoreValue());
					String cui = mm_elements.get(filename).get(i).getCandidates("map").get(cm).cuiValue() ;
					if (mm_elements.get(filename).get(i).getCandidates("map").get(cm).scoreValue()>500){
						System.out.println(cui+ " "+ mm_elements.get(filename).get(i).getCandidates("map").get(cm).scoreValue());
						cuis_cand.add(cui);
					}
				}
			}
		}
	}
	private static void getAllMatches(String term,
			int offset_beg, HashMap<String, MMC> maps, HashMap<String, MMC> candidates) {
		HashSet<String> matches = new HashSet<String>();
		for (String c : candidates.keySet()){
			if (candidates.get(c).getTerm().equalsIgnoreCase(term)){
				matches.add(candidates.get(c).cuiValue());
			}
			else if (candidates.get(c).getOffsetBeg()==offset_beg){
				matches.add(candidates.get(c).cuiValue());
			}
		}
		for (String c : maps.keySet()){
			if (maps.get(c).getTerm().equalsIgnoreCase(term)){
				matches.add(maps.get(c).cuiValue());
			}
			else if (maps.get(c).getOffsetBeg()==offset_beg){
				matches.add(maps.get(c).cuiValue());
			}
		}
		cui_matches = new HashSet<String>(matches);
	}

	private static boolean checkTerm(String utterance, String term) {
		String[] uttAr = utterance.split(" ");
		String regex = "[\\.\\?\\)\\]\\[\\(]";
		//System.out.println("utterance " + utterance +"," + term);
		for (int i = 0; i< uttAr.length; i++){
			//System.out.println("before regex " + uttAr[i]);
			//System.out.println("after regex " + uttAr[i].replaceAll(regex, ""));
			if (uttAr[i].replaceAll(regex, "").equalsIgnoreCase(term)){
			//	System.out.println("before regex " + uttAr[i]);
				return true;
			}
		}
		return false;
	}
	public static boolean fileNotEmpty()
	{  // System.out.println("file size = " + file_size);
		return file_size>0;
	}
	public static int getMatchValue(){
		return count;
	}
	public static String getCuiValue(){
		return cui_match;
	}
	public static HashSet<String> getallCuiValue(){
		return cui_matches;
	}
	private static String getMapValue(HashMap<String, MMC> candidates,
			String term, String utterance, int beg) {
		for (String x : candidates.keySet()){
			
			if (candidates.get(x).getTerm().equalsIgnoreCase(term)){
				if (debug)			System.out.println("term = " +candidates.get(x).getTerm());
				return x;
			}
			
		}
		//didn't find an exact match with term, need to look at offset
		return returnOffsetTerm(candidates, term, utterance, beg);
	}

	/**return the cui of term matched with offset numbers
	 * @param candidates
	 * @param term
	 * @param utterance
	 * @param beg
	 * @return 
	 */
	private static String returnOffsetTerm(HashMap<String, MMC> candidates,
			String term, String utterance, int beg) {
		String utt_lower = utterance.toLowerCase();
		int beg_idx = utt_lower.indexOf(term, 0)+beg;
		if (debug)		System.out.println("term = "+  term + " @ "+ beg_idx);
		for (String x : candidates.keySet()){
			if (candidates.get(x).getOffsetBeg() == beg_idx){
				if (debug)		System.out.println("term = " +candidates.get(x).getTerm()); 
				return x;}
			}
		return "";
	}
/*	private static HashMap<String, ArrayList<MM>> readFile(String filter,
			String input) throws IOException {//with just one file, hashmap will have just one entry
		
		String[] files = new String[1]; 
		files[0] = (input);
		System.out.println(files[0]);
		if (debug) System.out.println(input + " " +IOUtil.stripDir(input));
		return readFiles(files, filter, "");
	}*/
	private static HashMap<String, ArrayList<MM>> readFile(String filter, String input) throws IOException {
		HashMap<String,ArrayList<MM>> temp_mm_HM = new HashMap<String,ArrayList<MM>>();
		int count = 0;
			
			String filedir = IOUtil.stripDir(input);
			if (debug) System.out.println(filedir + ":" + input);
			
			if ((input).contains(filter)){//IOUtil.getFileExt
				ArrayList<MM> mm_list = new ArrayList<MM>();
				if (debug)			System.out.println(input);
			ArrayList<String> fileList = IOUtil.getTextFileInBuffer(input);
			if (debug) System.out.println(fileList.size() + " lines in " + input);
			ArrayList<String> tempU = new ArrayList<String> ();
			//System.out.println("0 "+ fileList.get(0));
			for (int j = 0;j<fileList.size();j++){
				//if (j==3){	System.out.println(j + " " + fileList.get(j));}
				if (!ignoreCond(fileList.get(j))){
					tempU = new ArrayList<String> ();
					while (!(fileList.get(j).equals("'EOU'."))){
						tempU.add(fileList.get(j));
						//System.out.println(fileList.get(j));
						j++;if (j==fileList.size()) break;
					}count++;
				}
				//on end of utterance, creat new mm
				MM tempMM = new MM(tempU); 
				
				if (tempMM.getUtterance() != ""){mm_list.add(tempMM);
				//System.out.println("new temp mm " + tempMM.getUtterance());

				}
				if (debug) System.out.println(input + ":::" + tempMM.toString());

			}
			
			temp_mm_HM.put(input,mm_list);
		}
			else {}
			
		
		if (debug)		System.out.println("mm count = " + count);
		return temp_mm_HM;
	}

	private static boolean ignoreCond(String string) {
		if (string.contains("args")){return true;}
		if (string.contains("neg_list")){return true;}
		if (string.contains("WARNING")){return true;}		
		if (string.contains("aas")){return true;}
		if (string==null){return true;}	
		return false;
	}


}
