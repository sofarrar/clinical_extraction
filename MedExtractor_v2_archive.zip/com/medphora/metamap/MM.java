package com.medphora.metamap;
import java.util.AbstractMap;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MM {
	private ArrayList<String> argument;
	private ArrayList<String> negList;
	private ArrayList<String> aasList;
	private String utterance;
	private String utterance_offset;
	
	private ArrayList<String> phraseList;
	private HashMap<String, MMC> candidateMap;
	private HashMap<String, MMC> mMap;
	private boolean process_cm = false;
	private boolean local_debug = false;
	public MM(ArrayList<String> tempU) {
		
		String cm = "";
		for (String s : tempU){
			//if (s.contains("stridor"))local_debug=true;
			if (local_debug){System.out.println(s);}
//			if (s.contains("args")){
//				argument = processArgs(s);
//			}
//			if (s.contains("aas")){
//				aasList = processAAS(s);
//			}
//			if (s.contains("neg_list")){
//				negList = processNeg(s);
//			}
			if (s.contains("utterance(")){
				SimpleEntry<String,String> tempUt = (processU(s)); 
				this.utterance = tempUt.getValue();
				this.utterance_offset = tempUt.getKey();
			}
			if (s.contains("phrase(")){
				this.phraseList = processPh(s);
			}
			if (s.contains("candidates(")){
			//	System.out.println("candidates:");
				this.candidateMap = processCand(s,false);
				if (this.candidateMap.containsKey("C0038450")) System.out.println("stridor ~!!cm!" + this.candidateMap.get("C0038450"));
			}
			if (s.contains("mappings")){
				//System.out.println("mappings:");
				this.mMap = processCand(s,true);
				if (this.mMap.containsKey("C0038450")) System.out.println("stridor ~!!mm!" + this.mMap.get("C0038450"));
			}
		}
	}
	@Override
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append(utterance + "-" + utterance_offset+"\t");
		if (this.mMap!=null){for (String x : this.mMap.keySet()){
			sb.append(x + ":" + this.mMap.get(x).cuiValue()+"\t");
		}}
		if (this.candidateMap!=null){for (String x : this.candidateMap.keySet()){
			sb.append(x + ":" + this.candidateMap.get(x).cuiValue()+"\t");
		}}
		
		return sb.toString() + "\n";
	}
/**
 *     mappings(
      [map(negated overall score for this mapping, 
            [ev(negated candidate score,'UMLS concept ID','UMLS concept','preferred name for concept - may or may not be different',
                 [matched word or words lowercased that this candidate matches in the phrase - comma separated list],
                 [semantic type(s) - comma separated list],
                 [match map list - see below],candidate involved with head of phrase - yes or no,
                 is this an overmatch - yes or no,
                 [Source List - comma separated list],
                 Positional Information

 * @param s
 * @param m map 
 * @return
 */
	private HashMap<String, MMC> processCand(String s, boolean m) {
		boolean map = m;//record final map (vs candidate)
	//	if (s.contains("stridor"))local_debug=true; 		
		String s1 = s;
		if (map){ s1 = s.replaceAll("map\\(-[0-9]*,\\[", ",");}
		String[] candAr = s1.split("ev\\(");
		String regex = "[\\)\\[\\]\\.]";
		//System.out.println("map = " + map);
		//cui's are unique, use them for keying candidate entries
		HashMap<String,MMC> cui_candidate = new HashMap<String,MMC>();
		for (int i = 1; i< candAr.length; i++)//split into candidates
		{
			
			//parse each individual candidate
			String[] singleCand = candAr[i].split(",");
			if (local_debug) System.out.println("candar= " + candAr[i] + "\n\t" + singleCand[0]);
//			if (candAr[0].contains("map")){map = true;}
			String[] singleCand2 = candAr[i].split("\\[");
			if (singleCand2.length>1&&singleCand.length>1){
			int score = Integer.parseInt(singleCand[0].replace("-", ""));
			String cui = singleCand[1].replaceAll("\'", "");
			String term = singleCand[2].toLowerCase();
			String offset = singleCand[singleCand.length-1].replaceAll(regex, "");
			
			String sem_type =singleCand2[1].replace(",\\]", "");
			List<String> semType = new ArrayList<String>();
			if (sem_type.contains((","))){
				String[] semAr = sem_type.split(",");
				for (int i1 = 0; i1<semAr.length;i1++){
					semType.add(semAr[i1]);
				}
				
			}else {semType.add(sem_type);}
			
			if (map){//System.out.println("map = " + map);
			MMC tempCand = new MMC(score,cui,term,offset,semType,true);
			if (local_debug) System.out.println(tempCand.toString());
			//System.out.println("this cand - map = " +tempCand.isMap_value());
			cui_candidate.put(cui, tempCand);}
			else{
				MMC tempCand = new MMC(score,cui,term,offset,semType);
				if (local_debug) System.out.println(tempCand.toString());
			//	System.out.println("this cand - map = " +tempCand.isMap_value() + tempCand.getTerm());
				cui_candidate.put(cui, tempCand);}
		
			}
		}
		
		return cui_candidate;
	}
	public HashMap<String, MMC> getCandidates(String filter){
		if (filter.equals("map")){
			return this.mMap;
		}
		else return this.candidateMap;
	}
	
	public String getUtterance(){
		if (this.utterance_offset!=null){
		return this.utterance_offset + ":" + this.utterance;}
		else return "";
	}
	public int getOffset(){
		if (this.utterance_offset!=null){
		return (Integer.parseInt(this.utterance_offset.split("_")[0]));}
		else return 0;
	}
//	phrase('Young adult-onset Parkinsonism'
//[mod([lexmatch(['young adult'])
//inputmatch(['Young',adult])
//tag(noun)
//tokens([young,adult])])
//punc([inputmatch([-])
//tokens([])])
//mod([lexmatch([onset])
//inputmatch([onset])
//tag(noun)
//tokens([onset])])
//head([lexmatch(['Parkinsonism'])
//inputmatch(['Parkinsonism'])
//tag(noun)
//tokens([parkinsonism])])]
//0/30
//[]).

	private ArrayList<String> processPh(String s) {
		String[] phrAr = s.replace("phrase(","").split(",");
		ArrayList<String> tokenList = getElements(phrAr, "tokens");
		return tokenList;	
	}



	private ArrayList<String> getElements(String[] phrAr, String elem) {
		ArrayList<String> tempList = new ArrayList<String>();
		for (int i = 0; i < phrAr.length;i++){
			if (phrAr[i].contains(elem)){
				String tempTok = phrAr[i].replace(elem+"(", "");
				String[] tempTokAr = tempTok.split(",");
				if (tempTokAr.length>1){
					for (int t = 0; t<tempTokAr.length;t++){
						tempList.add(tempTokAr[t].replaceAll("\\(\\[", "").replaceAll("\\]\\)", ""));
					}
				}
				else {tempList.add(tempTok.replaceAll("\\(\\[", "").replaceAll("\\]\\)", ""));}
			}
		}
		return tempList;
	}


	/**args
	 * ('metamap10.BINARY.Linux -Z 10 -q -z -R ICD9CM rare_diseases_list.txt rare_diseases_list.txt.q_icd9_term'
	 * [mm_data_year-'10'
	 * machine_output-[]
	 * term_processing-[]
	 * restrict_to_sources-['ICD9CM']
	 * infile-'rare_diseases_list.txt'
	 * outfile-'rare_diseases_list.txt.q_icd9_term']).
	 * 
	 * @param s
	 * @return
	 */

	private ArrayList<String> processArgs(String s) {
		String[] split_s = s.replace("args", "").split(",");
		split_s[0].replace("(\'", "").replace("\'","");

		return new ArrayList<String>(Arrays.asList(split_s));
	}
	/**
	 * aas([])
	 * @param s
	 * @param candidates
	 * @return
	 */
	private ArrayList<String> processAAS(String s) {
		String[] aas = checkIfEmpty(s, "aas");
		ArrayList<String> tempList = (ArrayList<String>)Arrays.asList(aas);
		return tempList;
	}
	private ArrayList<String> processNeg(String s) {
		String[] neg = checkIfEmpty(s, "neg_list");
		ArrayList<String> tempList = (ArrayList<String>)Arrays.asList(neg);
		return tempList;
	}	
	private String[] checkIfEmpty(String s, String element) {
		String temp = s.replace(element+"([", "").replace("].", "");
		if (temp.split(" ").length>1){return temp.split(" ");}
		return null;
	}

	/**
	 * utterance('00000000.tx.1',"Patent arterial duct",0/20,[]).
       utterance('00000000.tx.5',"The lesions within the spinal cord are numerous, involving the cervical and thoracic spinal cord.  ",247/99,[]).
	 * @param s
	 * @return
	 */
	private SimpleEntry<String, String> processU(String s) {
		String temp = s;//.replace("utterance(\'", "").replace("\\)\\.", "");
		String[] uAr = temp.split("\"");
		//if (s.contains("stridor")) local_debug = true;
		HashMap<String, String> tempMap = new HashMap<String, String>();
		String term  = "";
		int beg = 0;
		int len = 0;
		if (uAr.length>2){
		term = uAr[1];//.replaceAll("\"", "");
		if (local_debug) System.out.println(term);
		String[] offAr = uAr[2].split(",");
		for (int i = 0; i < offAr.length;i++){

		if (offAr[i].contains("/")){
			String[] offsetAr = offAr[1].split("/");
			beg = Integer.parseInt(offsetAr[0]);
			if (local_debug) System.out.println(beg);
			try{ len = Integer.parseInt(offsetAr[1]);}
			catch (ArrayIndexOutOfBoundsException aioe){System.out.println("ERROR splitting: offset = " +offAr[1]);}
		}
		}}
		else {
			}
		

		String key = (String)(beg+"_"+(beg+len));
		if (local_debug) 		System.out.println(" term = " +term + " " + uAr[0]);
		tempMap.put(key,term);
		return new SimpleEntry<String, String>(key,term);
	}

	
}
