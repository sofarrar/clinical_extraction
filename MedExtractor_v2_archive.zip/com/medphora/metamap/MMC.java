package com.medphora.metamap;

import java.util.List;

public class MMC {
	/**
	 * Candidate/Mapping object
	 */

	private String cui;
	private String term;
	private Integer score;
	private String offset;
	private List<String> semType;
	private boolean map_value;
	
	public MMC(int _score, String _cui, String _term, String _offset, List<String> _semType){
		this.cui = _cui;
		this.score = _score;
		this.term = _term.replaceAll("\'", "");
		this.offset = _offset.replace("/", "_");
		this.semType = _semType;
		
	}
	//for the final mapping 
	public MMC(int _score, String _cui, String _term, String _offset, List<String> _semType, boolean map){
		String regex = "[\\[\\(\\)\\]\\.]";
		this.cui = _cui;
		this.score = _score;
		this.term = _term.replaceAll("\'", "");
		this.offset = _offset.replace("/", "_").replaceAll(regex, "");
		this.semType = _semType;
		this.setMap_value(map);
		
	}
	@Override public String toString() {
		String map = (this.map_value)?"map":"candidate";
		return (this.term + "[" +this.offset + "]" + " (" + map + ")\n score=" + this.score + " \n cui="+this.cui);
	}
	public void setMap_value(boolean map_value) {
		this.map_value = map_value;
	}
	public boolean isMap_value() {
		return map_value;
	}
	public String cuiValue() {
		return this.cui;
	}
	public String getTerm() {
		return this.term;
	}
	public int getOffsetBeg() {
		if (this.offset.length()>0){
			try {		return Integer.parseInt(this.offset.split("_")[0]);}
			catch (NumberFormatException nfe){return -1;}
		}
			return -1;
		}
	public Integer scoreValue() {
		// TODO Auto-generated method stub
		return this.score;
	}
}
