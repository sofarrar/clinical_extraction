package com.medphora.ctakes;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.medphora.elements.TOKEN;
import com.medphora.util.IOUtil;

public class ParseCTAKES {

	/** CTAKES v2 name spaces
	 * public static final String NC_TOKEN = "edu.mayo.bmi.uima.core.type.WordToken";
	public static final String NC_UMLS = "edu.mayo.bmi.uima.core.type.UmlsConcept";
	public static final String NC_NE = "edu.mayo.bmi.uima.core.type.NamedEntity";
	public static final String NC_TOKEN = "edu.mayo.bmi.uima.core.type.WordToken";
	 */
	public static final String NC_TOKENW= "org.apache.ctakes.typesystem.type.syntax.WordToken";
	public static final String NC_TOKENP=("org.apache.ctakes.typesystem.type.syntax.PunctuationToken");
	public static final String NC_TOKENS=("org.apache.ctakes.typesystem.type.syntax.SymbolToken");
	public static final String NC_TOKENN=("org.apache.ctakes.typesystem.type.syntax.NumToken");
	public static final String NC_NE=("org.apache.ctakes.typesystem.type.textsem.EntityMention");
	public static final String NC_UMLS=("org.apache.ctakes.typesystem.type.refsem.UmlsConcept");
	public static final String NC_MA=("org.apache.ctakes.assertion.medfacts.types.Concept");
	public static TreeMap<Integer,TOKEN> NEmap = new  TreeMap<Integer,TOKEN> ();
	public static TreeMap<Integer,TOKEN> UMLSmap = new  TreeMap<Integer,TOKEN> ();

	public static final String temp_dir = System.getProperty("user.dir") +IOUtil.fileSeparator + "temp"+IOUtil.fileSeparator;

	public static void main(TreeMap<Integer, TOKEN> tokenmap, String note,
			String cTAKES) throws IOException, ParserConfigurationException, SAXException {
		Document doc  = runCTAKES(note,cTAKES);
		NodeList nl_fs = doc.getElementsByTagName("uima.cas.FSArray");
		HashMap<Integer,Integer> ontology_fs_map = getFSMap(nl_fs);

		getTokens(tokenmap, doc, ontology_fs_map);
		updateUMLSNE();
		updateTOKEN(tokenmap);
		//countTUIS(tokenmap);
	}

	public static Document runCTAKES(String note, String ctakes_loc) throws IOException, ParserConfigurationException, SAXException {
		Document doc = null;
		 

		if (!new File(temp_dir).isDirectory() ){
			//make temp dir for xml input, note input
			new File(temp_dir).mkdir();
		}
		else {
			//FileUtils.cleanDirectory(new File(temp_dir));
		}
		// create FilesToFiles.xml configuration file (for each file)
		StringBuffer sb_f2fBuffer = IOUtil.getTextFile(System.getProperty("user.dir")+IOUtil.fileSeparator + "data" + IOUtil.fileSeparator + "FilesToFiles2_windows.xml");
		String f2f_str = sb_f2fBuffer.toString();
		//REPLACE rest of strings for xml recreation
		String temp = f2f_str.replace("%INPUT%",note);
		f2f_str = temp.replace("%OUTPUT%",temp_dir);System.out.println(ctakes_loc);
		temp = f2f_str.replaceAll("%","\\"+IOUtil.fileSeparator);
		f2f_str = temp.replaceAll("CTAKES_HOME",IOUtil.fileSeparator+ctakes_loc);	

		System.out.println(f2f_str);
		IOUtil.putTextFile(temp_dir.replace("\\\\", "\\\\") + IOUtil.fileSeparator + "files.xml", new StringBuffer(f2f_str));
		System.out.println(temp_dir.replace("\\\\", "\\\\") + IOUtil.fileSeparator + "files.xml");
		// TODO connect to ctakes command line runner
		System.out.println(note);
		//	Runtime.getRuntime().exec("cmd /c start " + ctakes_loc +IOUtil.fileSeparator + "bin"+IOUtil.fileSeparator + "runctakesCMD.bat");
		//read doc from ctakes output
		//output will be input note 
		String outnote = note.replace("medphora_data","medphora_data_out").replace(".txt", ".txt.xml");
		doc = IOUtil.readXMLFile(outnote);//D:\\db\\source\\ctakes_parse2\\wsd_6975.txt.xml
		return doc;
	}
	/**get Map of FSArray(NE-UMLS concepts) from ctakes output
	 * @param nl_fs
	 * @return
	 */
	private static HashMap<Integer, Integer> getFSMap(NodeList nl_fs) {
		HashMap<Integer, Integer> map = new  HashMap<Integer, Integer> ();
		String fsid = "",subid="";
		for (int i = 0; i < nl_fs.getLength(); i++){
			NamedNodeMap subnl=nl_fs.item(i).getAttributes();

			for (int j = 0; j<subnl.getLength();j++){
				if (subnl.item(j).getNodeName().equals("_id")){
					fsid=(subnl.item(j).getTextContent());}
				int fsid_int = Integer.parseInt(fsid);

				for (int k = 1; k<nl_fs.item(i).getChildNodes().getLength(); k++){

					try{

						int oid_int = Integer.parseInt(nl_fs.item(i).getChildNodes().item(k).getTextContent());
						map.put(oid_int, fsid_int);
					}
					catch (NumberFormatException nfe){}
					//System.out.println(fsid + ": " + nl_fs.item(i).getChildNodes().item(k).getTextContent());

				}
			}
		}
		return map;
	}
	private static void getTokens(TreeMap<Integer,TOKEN> tokenmap,Document doc, HashMap<Integer, Integer> ontology_fs_map) {
		NodeList nl_w = doc.getElementsByTagName(NC_TOKENW);//ctakes 3.0 NC_TOKENW
		NodeList nl_p = doc.getElementsByTagName(NC_TOKENP);//NC_TOKENP
		NodeList nl_s = doc.getElementsByTagName(NC_TOKENS);//NC_TOKENS
		NodeList nl_n = doc.getElementsByTagName(NC_TOKENN);//NC_TOKENN
		NodeList nl_ne = doc.getElementsByTagName(NC_NE);
		NodeList nl_u = doc.getElementsByTagName(NC_UMLS);
		NodeList nl_ma = doc.getElementsByTagName(NC_MA);
		TreeMap<Integer,TOKEN> MAmap = new TreeMap<Integer,TOKEN>();
		readTokenType(tokenmap, nl_w,"w",ontology_fs_map);
	//don't collect symbols
	/*	
		System.out.println(tokenmap.size() + " token size");
		readTokenType(tokenmap, nl_s,"s");*/
		//System.out.println(tokenmap.size() + " token size");
		//readTokenType(tokenmap, nl_p,"p",ontology_fs_map);
		System.out.println(tokenmap.size() + " token size");
		readTokenType(tokenmap, nl_n,"n",ontology_fs_map);
		readTokenType(NEmap, nl_ne,"ne",ontology_fs_map);
		readTokenType(MAmap, nl_ma,"ma",ontology_fs_map);
		mergeNE(MAmap);
		updateNEText(NEmap,tokenmap);

		readTokenType(UMLSmap, nl_u,"umls",ontology_fs_map);
	}
	private static void mergeNE(TreeMap<Integer, TOKEN> MAmap) {
		for (Integer i : NEmap.keySet()){
			if (MAmap.containsKey(i)){
				NEmap.get(i).mergeMA(MAmap.get(i));
				
			}
		}
		
	}

	/**
	 * @param tokenmap
	 * @param nl
	 * @param ontology_fs_map 
	 */
	private static void readTokenType(TreeMap<Integer, TOKEN> tokenmap,
			NodeList nl,String type, HashMap<Integer, Integer> ontology_fs_map) {
		//System.out.println("reading " + type + " tokens " + nl_w.getLength());
		for (int i = 0; i < nl.getLength(); i++){
			NamedNodeMap subnl=nl.item(i).getAttributes();
			//System.out.println(subnl.getLength() + " attributes nodes of " + nl_w.item(i).getNodeName());
			TOKEN _token = null;
			if (type.equals("ne")||type.equals("umls")){
				_token = readNETokens(subnl,type,ontology_fs_map);
			}
			else {_token = readXMLTokens(subnl,type);}

			tokenmap.put(_token.getTokenNum(), _token);
		}
	}

	private static TOKEN readNETokens(NamedNodeMap subnl, String type, HashMap<Integer, Integer> ontology_fs_map) {
		String _id = "",token="",beg="",end="",norm="",pos="",oid="",pol="",unc="",cond="",conf="",codetype="",code="",cui="",tui="",fsid="",concept="";
		int tokennum = 0; 
		boolean debug= (type.equals("ne")); 
		for (int j = 0; j<subnl.getLength();j++){
		//org.apache.ctakes.assertion.medfacts.types.Concept _indexed="" _id="" _ref_sofa="" begin="" end="" conceptType="TEST" conceptText="" externalId="" originalEntityExternalId=""/>
			if (subnl.item(j).getNodeName().equals("conceptType")){
				concept=subnl.item(j).getTextContent();
			}
			if (subnl.item(j).getNodeName().equals("conceptText")){
				norm=subnl.item(j).getTextContent().toLowerCase();
				token=subnl.item(j).getTextContent();
			}
			if (subnl.item(j).getNodeName().equals("_ref_ontologyConceptArr")){
				oid=subnl.item(j).getTextContent();
		//		if (debug)System.out.println("_ref_ontologyConceptArr " + oid);
			}
			if (subnl.item(j).getNodeName().equals("originalEntityExternalId")){
				oid=subnl.item(j).getTextContent();
			}
			
			if (subnl.item(j).getNodeName().equals("conditional")){
				cond=subnl.item(j).getTextContent();}
			if (subnl.item(j).getNodeName().equals("uncertainty")){
				unc=subnl.item(j).getTextContent();}
			if (subnl.item(j).getNodeName().equals("confidence")){
				conf=subnl.item(j).getTextContent();}
			if (subnl.item(j).getNodeName().equals("polarity")){
				pol=subnl.item(j).getTextContent();}
			
			if (subnl.item(j).getNodeName().equals("codingScheme")){
				codetype=subnl.item(j).getTextContent();}
			if (subnl.item(j).getNodeName().equals("code")){
				code=subnl.item(j).getTextContent();}
			if (subnl.item(j).getNodeName().equals("cui")){
				cui=subnl.item(j).getTextContent();}
			if (subnl.item(j).getNodeName().equals("tui")){
				tui=subnl.item(j).getTextContent();}
			if (subnl.item(j).getNodeName().equals("_id")){
				_id=subnl.item(j).getTextContent();
			}
			if (subnl.item(j).getNodeName().equals("begin")){
				beg=subnl.item(j).getTextContent();

			}
			if (subnl.item(j).getNodeName().equals("tui")){
				tui=(subnl.item(j).getTextContent());
//				if (debug) System.out.println("token " + token);
			}
			if (subnl.item(j).getNodeName().equals("end")){
				end=subnl.item(j).getTextContent();

			}
			
			if (type.equals("umls")){
			fsid=ontology_fs_map.get(Integer.parseInt(_id))+"";
			}
			else if (type.equals("ma")){
				fsid=ontology_fs_map.get(Integer.parseInt(oid))+"";
			}
		}
		TOKEN _token =null;
		
		
		if (type.equals("ne")||type.equals("ma")){	
			_token = new TOKEN(oid,beg,end,type,_id); //
			_token.updateNE(oid,pol,unc,cond,conf);
			if (!concept.equals("")) _token.updateConcept(concept);
			if (type.equals("ma")){
				_token.updateFSARRAY(fsid);
			}
		}
		else if (type.equals("umls")){
			_token = new TOKEN(codetype,code,cui,tui,type,_id); //
			if (!fsid.equals("null"))_token.updateFSARRAY(fsid);	
			}
		
		return _token;
	}

	private static void updateNEText(TreeMap<Integer, TOKEN> nEmap,
			TreeMap<Integer, TOKEN> tokenmap) {
		
		HashSet<Integer> ids = new HashSet<Integer>();
		for (int n : nEmap.keySet()){
			StringBuffer sb = new StringBuffer();
			TOKEN netok =nEmap.get(n);
		for (int i : tokenmap.keySet()){
			if (tokenmap.get(i).getType().equals("w")){
			if (tokenmap.get(i).getBeg() == netok.getBeg()){//add first
				sb.append(tokenmap.get(i).getToken() + " ");
				
			}
			if (tokenmap.get(i).getBeg() > netok.getBeg()){//add middle, last
				if (tokenmap.get(i).getEnd() <= netok.getEnd()){
					sb.append(tokenmap.get(i).getToken() + " ");	
				}
			}
			
		}
		}
	//	System.out.println(_token + " add " + sb.toString());
		nEmap.get(n).updateTxt(sb.toString());
	}
	}
	/**
	 * @param subnl
	 * @param type 
	 * @return
	 */
	private static TOKEN readXMLTokens(NamedNodeMap subnl, String type) {
		String _id = "",token="",beg="",end="",norm="",pos="",oid="",pol="",unc="",cond="",conf="";
		int tokennum = 0; 
		boolean debug= (type.equals("ne")); 
		for (int j = 0; j<subnl.getLength();j++){

			if (subnl.item(j).getNodeName().equals("_id")){
				_id=subnl.item(j).getTextContent();
			}
			if (subnl.item(j).getNodeName().equals("begin")){
				beg=subnl.item(j).getTextContent();

			}
			if (subnl.item(j).getNodeName().equals("end")){
				end=subnl.item(j).getTextContent();

			}
			if (subnl.item(j).getNodeName().equals("normalizedForm")){
				norm=subnl.item(j).getTextContent();
//				if (debug) System.out.println("token " + norm);
			}
			if (subnl.item(j).getNodeName().equals("partOfSpeech")){
				pos=subnl.item(j).getTextContent();

			}
			if (subnl.item(j).getNodeName().equals("tokenNumber")){
				tokennum=Integer.parseInt(subnl.item(j).getTextContent());
			}
			if (subnl.item(j).getNodeName().equals("canonicalForm")){
				token=(subnl.item(j).getTextContent());
//				if (debug) System.out.println("token " + token);
			}
			
		}
		//System.out.println(_id + " : " + norm + " " + beg + "-"+end + "(" +pos +")");
		TOKEN _token =new TOKEN(tokennum,beg,end,norm,token,type,pos,_id); //
		
		
		
		return _token;
	}
	private static String getGram(int gNumber, ArrayList<Integer> token_id_list,int list_idx, TreeMap<Integer, TOKEN> tokenmap) {
		String token = "";
		System.out.println("gNumber " + gNumber + " list " + token_id_list.get(gNumber));
		for (int k = gNumber; k>0; k--){
		if (token_id_list.size() > (list_idx + gNumber)){
			System.out.println("k " + k + " list " + token_id_list.get(k));
			if (k==gNumber) token = tokenmap.get(token_id_list.get(k)).getToken();
			else token+="-"+tokenmap.get(token_id_list.get(k)).getToken();
		}
		}
		return null;
	}

	private static void updateNgram(HashMap<String, HashSet<String>> pt_ngrams, String ngram, String pt) {
		if (!pt_ngrams.containsKey(pt)){
			pt_ngrams.put(pt, new HashSet<String>());
		}
		pt_ngrams.get(pt).add(ngram);		
	}
	private static void updateUMLSNE() {
		for (Integer n : NEmap.keySet()){
			
			if (UMLSmap.containsKey(n)){
				
				UMLSmap.get(n).mergeNE(NEmap.get(n));
				NEmap.get(n).mergeUMLS(UMLSmap.get(n));
				
				System.out.println("MATCHING: " + n + " " + NEmap.get(n).getID() + " "+ NEmap.get(n) + "\n\t" + UMLSmap.get(n));
			}
		}
	}

	private static void countTUIS(TreeMap<Integer, TOKEN> tokenmap) {
		int c = 0;
		for (Integer i : tokenmap.keySet()){
			c+=tokenmap.get(i).getTUI().size();
		}
		System.out.println("TUIS " + c);
	}

	private static void updateTOKEN(TreeMap<Integer, TOKEN> tokenmap) {
		for (Integer n : NEmap.keySet()){
			int n_beg = NEmap.get(n).getBeg();
			int n_end = NEmap.get(n).getEnd();
			for (Integer i : tokenmap.keySet()){
				if (n_beg == tokenmap.get(i).getBeg() || n_end == tokenmap.get(i).getEnd()){
					tokenmap.get(i).mergeUMLSNE(NEmap.get(n));
				}
			}
		}
		
	}
}

