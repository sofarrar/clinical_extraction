package com.medphora.elements;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;


public class PatientSlot {
	
	//results for details involving this patient
	NameSlot names;
	AgeSlot age;
	ReasonSlot reason;
	
	ArrayList<SingleSlot> allSlots;//collection of all slots
	
	//names of slots not relevant (e.g. conditions for doctor)
	HashSet<String> ignoreSlots;
	
	
	public PatientSlot(){
		initSlot();
	}

	private void initSlot() {
		this.allSlots = new ArrayList<SingleSlot>();
		this.ignoreSlots = new HashSet<String>();
		
	}

	public void addSlot(ArrayList<SingleSlot> slot_list) {
		for (SingleSlot ss : slot_list){
			
			this.allSlots.add(ss);
			if (ss.getClass().equals("NameSlot")) this.names = (NameSlot) ss;
			else if (ss.getClass().equals("AgeSlot")) this.age = (AgeSlot) ss;
		}
		
	}
		
	/**
	 * prints all slots except those in nullSlots or ignoreslots
	 */
	public void print() {
		for (SingleSlot slot : allSlots) {
			//TODO implement print method
		}
	}

	
}

