package com.medphora.elements;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

public abstract class SingleSlot {

	protected String type;
	
	/**
	 * process token map to find slot according to logic of the slot
	 * @param _tokenMap
	 * @throws FileNotFoundException
	 */
	public abstract void process(TreeMap<Integer,TOKEN> _tokenMap) throws FileNotFoundException;

	/**
	 *Resolve ambiguity in slot list.
	 */
	public abstract void inference();
	
	@Override
	public String toString(){	return this.type; }
	
	/**
	 * validate slot match -TOKEN object according to original text
	 * @param text
	 */
	public abstract void validate(StringBuffer text);
	
	
}
