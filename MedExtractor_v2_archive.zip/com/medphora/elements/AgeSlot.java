package com.medphora.elements;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.medphora.elements.SingleSlot;

public class AgeSlot extends SingleSlot {

	HashSet<SingleSlot> age_list;
	String age;
	private int offset_beg=0;
	private int offset_end=0;

	HashSet<String> patterns;

	public AgeSlot(TreeMap<Integer, TOKEN> tokenmap) {
		initSlot();
		process(tokenmap);
	}

	public AgeSlot(String age_string, int beg, int end) {
		 this.age = age_string; 
		 this.offset_beg = beg; 
		 this.offset_end = end;
	}

	private void initSlot() {
		this.patterns = new HashSet<String>(Arrays.asList("week","month","year"));
		this.age_list = new HashSet<SingleSlot>();

	}

	/**
	 * Process ageslot, look for patterns in tokenmap that match week, month, year
	 */
	@Override
	public void process(TreeMap<Integer,TOKEN> _tokenMap) {
		int cur_id = -1;
		ArrayList<Integer> idlist = new ArrayList<Integer>(_tokenMap.keySet());
		for (Integer i : _tokenMap.keySet()){
			cur_id++;
			
			for (String p : patterns){
				Pattern pp = Pattern.compile(".*("+p+").*");
				 //System.out.println("checking " + _tokenMap.get(i).getToken() + " " + p);
				Matcher matcher = pp.matcher(_tokenMap.get(i).getToken());
				StringBuffer sb = new StringBuffer();
				int end=0,beg=0;
				 while (matcher.find()) {
					// System.out.println(_tokenMap.get(i).getToken() + "=" + matcher.group());
					 sb.append(matcher.group());
					 end=_tokenMap.get(i).getEnd();
					 for (int bt = cur_id; bt>(cur_id-5); bt--){
						// System.out.println("prev " + bt + " =" + _tokenMap.get(idlist.get(bt)).getToken());
						 try {
							 Integer.parseInt(_tokenMap.get(idlist.get(bt)).getToken()); 
							 sb.insert(0, _tokenMap.get(idlist.get(bt)).getToken() + " ");
							 beg = _tokenMap.get(idlist.get(bt)).getBeg();
							 break;//stop looking back if number is found
							 }
						 catch (NumberFormatException nfe){continue;}
					 }
					 if (sb.toString().equals(matcher.group())){sb = new StringBuffer();}
					 else{// System.out.println(sb +  " " + beg + "-" + end );
					 this.age = sb.toString(); this.offset_beg = beg; this.offset_end = end;
					 this.age_list.add(new AgeSlot(sb.toString(),beg,end));//keep list of found ages.
					 }
				 }
				
			}
		}

	}



	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public int getOffset_beg() {
		return offset_beg;
	}

	public void setOffset_beg(int offset_beg) {
		this.offset_beg = offset_beg;
	}

	public int getOffset_end() {
		return offset_end;
	}

	public void setOffset_end(int offset_end) {
		this.offset_end = offset_end;
	}

	@Override
	public void inference() {
	}

	/**
	 * attempts to match year with a regular expression
	 */
	@Override
	public void validate(StringBuffer text) {
		if (this.age!=null){
			String a = this.age;
			if (this.offset_beg>0&& this.offset_end>0){
				String n_check = text.substring(this.offset_beg,this.offset_end);
				if (n_check.equals(a)){System.out.println("valid input " + this.toString());}
				else System.out.println("invalid text " + n_check + " != " + a  + "[" + this.offset_beg + "-" + this.offset_end +"]");
			}
			else System.out.println("invalid offsets: " + this.offset_beg + "-" + this.offset_end);
		}
		else System.out.println("invalid input: " + this.toString());
	}

}
