package com.medphora.elements;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.medphora.elements.SingleSlot;

public class NameSlot extends SingleSlot {

	HashSet<String> names;

	ArrayList<String> patterns;
	private String fname;
	private String lname;

	private int offset_beg=0;
	private int offset_end=0;
	private String target_flag = "patient";
	
	
	public NameSlot(String _fname, String _lname, int _offset_beg, int _offset_end) {
		this.setFname(_fname);
		this.setLname(_lname);
		this.setOffset_beg(_offset_beg);
		this.setOffset_end(_offset_end);
	}

	
	public NameSlot(TreeMap<Integer, TOKEN> tokenmap) {
		initSlot();
		process(tokenmap);
		addNames();
	}

	private void initSlot() {
		this.names=new HashSet<String>();
		
	}


	private void addNames() {
		System.out.println(toString());
		names.add(this.fname.toLowerCase());
		names.add(this.lname.toLowerCase());		
	}


	public String getName(){return this.fname + " " + this.lname;}
	
	@Override
	public void process(TreeMap<Integer,TOKEN> _tokenMap) {
		for (Integer i : _tokenMap.keySet()){
			if (_tokenMap.get(i).getToken().equals(target_flag)){
				if (!_tokenMap.containsKey(i+1)) {//no word token, after flag token is punctuation
					this.setFname(_tokenMap.get(i+2).getToken());
					this.setLname(_tokenMap.get(i+3).getToken());
					this.setOffset_beg(_tokenMap.get(i+2).getBeg());
					this.setOffset_end(_tokenMap.get(i+3).getEnd());
				}
			}
			
			
		}	
	}

	@Override
	public void inference() {
		//TODO
	}

	/**
	 * attempts to match name offsets with input text
	 */
	@Override
	public void validate(StringBuffer text) {
		if (this.fname != null && this.lname != null){
			String n = this.getName();
			if (this.offset_beg>0&& this.offset_end>0){
					String n_check = text.substring(this.offset_beg,this.offset_end);
					if (n_check.equals(n)){System.out.println("valid input " + this.toString());}
					else System.out.println("invalid text " + n_check + " != " + n  + "[" + this.offset_beg + "-" + this.offset_end +"]");
				}
				else System.out.println("invalid offsets: " + this.offset_beg + "-" + this.offset_end);
			}
			else System.out.println("invalid input: " + this.toString());

	}
	@Override
	public String toString(){
		return this.fname + " " + this.lname + " [" + this.offset_beg + "-" + this.offset_end+"]";
	}

	public int getOffset_end() {
		return offset_end;
	}


	public void setOffset_end(int offset_end) {
		this.offset_end = offset_end;
	}


	public int getOffset_beg() {
		return offset_beg;
	}


	public void setOffset_beg(int offset_beg) {
		this.offset_beg = offset_beg;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	
}
