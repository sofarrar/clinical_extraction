package com.medphora.elements;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;


public class ReasonSlot extends SingleSlot {

	
	public ReasonSlot() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void process(TreeMap<Integer, TOKEN> _tokenMap)
			throws FileNotFoundException {
		// TODO Auto-generated method stub

	}

	@Override
	public void inference() {
		// TODO Auto-generated method stub

	}

	@Override
	public void validate(StringBuffer text) {
		// TODO Auto-generated method stub

	}

}
