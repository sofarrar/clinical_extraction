package com.medphora.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class IOUtil {
	public static final String lineSeparator = System
			.getProperty("line.separator");
	public static final String fileSeparator = System
			.getProperty("file.separator");
	private static final String windowsNewline = "\r\n";
	private static final String unixNewline = "\n";
	private static final String oldMacNewline = "\r";
	private static String checkHeurDisplay = null;
	private static DocumentBuilderFactory dbf = DocumentBuilderFactory
			.newInstance();
	/**
	 * Read a text file from the file system into a StringBuffer.
	 * 
	 * @param fileName
	 *            : the name of the original text file to be annotated
	 * @return StringBuffer: the file read in.
	 */
	public static StringBuffer getTextFile(String fileName) throws IOException {
		InputStreamReader reader = null;
		BufferedReader bufferReader = null;
		String line = null;
		StringBuffer result = new StringBuffer();
		try {
			reader = new InputStreamReader(new FileInputStream(fileName),
					"UTF8");
			bufferReader = new BufferedReader(reader);
			int ch;
			while ((ch = reader.read()) > -1) {
				result.append((char) ch);
			}
		} catch (FileNotFoundException fe) {
			System.out.println("File " + fileName + " is not found.");
			System.exit(1);
		} catch (IOException ioe) {
			System.out.println("File " + fileName + ioe.getMessage());
			System.exit(1);
		} finally {
			if (bufferReader != null) {
				try {
					bufferReader.close();
				} catch (IOException ioe) {
				}
			}
		}

		return result;
	}

	public static Document readXMLFile(String fileName) throws IOException,
	ParserConfigurationException, SAXException {
File file = new File(fileName);
DocumentBuilder db = dbf.newDocumentBuilder();
Document doc = db.parse(file);

return doc;
}
	
	/**
	 * Get the annotation structure as a string from a Json file created by
	 * MIST.
	 * 
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static StringBuffer getJsonTextFile(String fileName)
			throws IOException {
		InputStreamReader reader = null;
		BufferedReader bufferReader = null;
		String line = null;
		StringBuffer result = new StringBuffer();
		try {
			reader = new InputStreamReader(new FileInputStream(fileName),
					"UTF8");
			bufferReader = new BufferedReader(reader);
			while ((line = bufferReader.readLine()) != null) { // while loop
																// begins here
				result.append(line);
			}
		} catch (FileNotFoundException fe) {
			System.out.println("File " + fileName + " is not found.");
			System.exit(1);
		} catch (IOException ioe) {
			System.out.println("File " + fileName + ioe.getMessage());
			System.exit(1);
		} finally {
			if (bufferReader != null) {
				try {
					bufferReader.close();
				} catch (IOException ioe) {
				}
			}
		}
		countNewline(result);
		return result;
	}

	private static void countNewline(StringBuffer result) {
		String resultString = result.toString();
		for (int i = 0; i < resultString.length(); i++) {
			int index = resultString.indexOf("\n");
			if (index >= 0 && index + 10 <= resultString.length()) {
				System.out.println(index + resultString.substring(index, 10));
				resultString.replace("\n", " ");
			} else
				break;
		}
	}

	/**
	 * Read a text file and return it as a list of the line strings.
	 * 
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static ArrayList<String> getTextFileInBuffer(String fileName)
			throws IOException {
		ArrayList<String> lineList = new ArrayList<String>();
		InputStreamReader reader = null;
		BufferedReader bufferReader = null;
		String line = null;
		File fn = new File(fileName);
		try {
			reader = new InputStreamReader(new FileInputStream(fileName));
			bufferReader = new BufferedReader(reader);
			while ((line = bufferReader.readLine()) != null) {
				lineList.add(line);
			}
		} catch (FileNotFoundException fe) {
			System.out.println("File " + fileName + " is not found.");
			System.out.println("file path = " + fn.getAbsolutePath());
			System.exit(1);
		} catch (IOException ioe) {
			System.out.println("File " + fileName + ioe.getMessage());
			System.exit(1);
		} finally {
			if (bufferReader != null) {
				try {
					bufferReader.close();
				} catch (IOException ioe) {
				}
			}
		}

		return lineList;
	}

	/**
	 * Write the contents of the buffer into the file.
	 * 
	 * @param fileName
	 *            : the output file name
	 * @param buffer
	 *            : the buffer to write out
	 * @throws IOException
	 */
	public static void putTextFile(String fileName, StringBuffer buffer)
			throws IOException {
		String tempName = fileName;
		OutputStreamWriter writer = null;
		writer = new OutputStreamWriter(new FileOutputStream(tempName));
		writer.write(buffer.toString());
		writer.flush();
		writer.close();
	}
	public static void makeFolder(String fullPathName){
		if (!isFolder(fullPathName)){
			new File(fullPathName).mkdir();
		}
	}
	public static void putTextFile(String fileName, ArrayList<String> lineList)
			throws IOException {
		// encoding is ISO-8859-1 be default

		String tempName = fileName;
		OutputStreamWriter writer = null;
		writer = new OutputStreamWriter(new FileOutputStream(tempName));
		for (String line : lineList) {
			writer.write(line);
		}
		writer.flush();
		writer.close();
	}

	/**
	 * See if the last character in the string is a newline.
	 * 
	 * @param line
	 *            : the text to test
	 * @return boolean: true if the line ends with newline, false otherwise
	 */
	public static boolean isEndWithNewLine(String line) {
		boolean endWithNewLine = false;
		if (line.endsWith(windowsNewline) || line.endsWith(unixNewline)
				|| line.endsWith(oldMacNewline))
			endWithNewLine = true;
		return endWithNewLine;
	}

	/**
	 * Generate a fileName that matches the input file name, but it is in the
	 * output directory.
	 * 
	 * @param fileNameIn
	 * @param outFolder
	 * @return
	 */
	public static String generateFileName(String fileNameIn) {
		String outFileName = null;
		int index = fileNameIn.lastIndexOf(File.separator);
		if (index > 0) {
			String outFolder = fileNameIn.substring(0, index);
			outFileName = generateFileName(fileNameIn, outFolder);
		}
		return outFileName;
	}

	public static String generateFileName(String fileNameIn, String outFolder) {
		String outFileName = null;
		String extension = "_p.json";
		int index = fileNameIn.lastIndexOf(File.separator);
		if (index > 0) {
			outFileName = outFolder + File.separator
					+ fileNameIn.substring(index + 1) + extension;
		} else
			outFileName = fileNameIn + extension;
		return outFileName;
	}
	public static String generateFileName(String fileNameIn, String outFolder, String ext, String subDir) {
		String outFileName = null;
		String extension = ext;
		int index = fileNameIn.lastIndexOf(File.separator);
		if (index > 0) {
			outFileName = outFolder + File.separator + subDir + File.separator +  File.separator
					+ fileNameIn.substring(index + 1) + extension;
		} else
			outFileName = fileNameIn + extension;
		return outFileName;
	}
	public static String stripDirectory(String fileName, String subDir){
		String outFileName = null;
		int index = fileName.lastIndexOf(File.separator);
		if (index > 0) {
		String outFolder = fileName.substring(0, index);
		outFileName = generateFileName(fileName, outFolder,".medspan",subDir);
		}
		return outFileName;
	}
	public static String splitFileExt(String fileName) {
		int index = fileName.indexOf(".",0);
		
		return fileName.substring(0,index);
	}
	/**
	 * See if fileName refers to a folder or not.
	 * 
	 * @param fileName
	 * @return
	 */
	public static boolean isFolder(String fileName) {
		boolean ifFolder = false;
		File file = new File(fileName);
		if (file.exists() && file.isDirectory())
			ifFolder = true;
		return ifFolder;
	}
	
	
	public static String[] getDir(File input_dir) {
		String[] filenames;
		if (!input_dir.exists()){throw new Error("no input directory specified");}
		else{
			filenames = input_dir.list();
		}
		
		return filenames;
	}

	public static void checkDir(String output_dir){
		boolean exist_out = (new File(output_dir).exists());
		if (exist_out){//need to remove all previously copied files
			File o = new File(output_dir);
			File[] files = o.listFiles(); 
			for (File file : files) {
				file.delete();
			}
		}
		else {new File(output_dir).mkdir();}	//if it doesn't exist, create the dir
	}
	public static String stripDir(String fileName){
		String outFolder = null;
		int index = fileName.lastIndexOf(File.separator);
		if (index > 0) {
		outFolder = fileName.substring(0, index);
		}
		return outFolder;
	}
}
